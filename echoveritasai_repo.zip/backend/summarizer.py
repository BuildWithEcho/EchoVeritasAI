# Text summarization logic
