# Bias scoring logic
