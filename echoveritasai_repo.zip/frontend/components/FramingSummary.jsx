// Framing summary component
