import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";

export default function SourceVerifierApp() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleSubmit = async () => {
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch("http://127.0.0.1:5000/api/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });

      const data = await res.json();
      setResult(data);
    } catch (error) {
      setResult({ output: "Failed to fetch results. Please try again later." });
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-red-500 text-white p-6 font-sans">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-5xl font-extrabold mb-4 tracking-tight text-white drop-shadow-md">
          🔍 Source Verifier
        </h1>
        <p className="text-zinc-400 mb-8 text-lg">
          Enter a news article URL to analyze its bias, generate a neutral summary, and compare it to other sources.
        </p>
        <div className="flex gap-4 mb-8">
          <Input
            placeholder="Paste article URL here..."
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            className="flex-1 border border-zinc-700 bg-zinc-800 text-white"
          />
          <Button onClick={handleSubmit} disabled={loading} className="bg-indigo-600 hover:bg-indigo-700">
            {loading ? <Loader2 className="animate-spin w-4 h-4" /> : "Verify"}
          </Button>
        </div>

        {result && (
          <Card className="bg-zinc-800 text-left shadow-xl border border-zinc-700">
            <CardContent className="p-6 space-y-4">
              <div>
                <h2 className="text-xl font-semibold text-indigo-400 mb-2">🧭 Bias Score Legend:</h2>
                <ul className="text-sm text-zinc-300 list-disc ml-6">
                  <li>-1.0 → Far Left</li>
                  <li>-0.5 → Left-Leaning</li>
                  <li>0.0 → Neutral / Centrist</li>
                  <li>+0.5 → Right-Leaning</li>
                  <li>+1.0 → Far Right</li>
                </ul>
              </div>

              <p><strong>📰 Source Domain Bias:</strong> {result.sourceBias}</p>
              <p><strong>🧠 Content Bias Score:</strong> {result.contentBias}</p>
              <p><strong>🔍 Extraction Method:</strong> {result.extractionMethod}</p>

              <div>
                <h3 className="text-lg font-semibold text-indigo-300">📄 Summary + Explanation:</h3>
                <Textarea
                  className="bg-zinc-900 text-white mt-2 border border-zinc-600 rounded-md p-3"
                  rows={result.output.split("\n").length + 2}
                  value={result.output}
                  readOnly
                />
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

